import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;
import javax.swing.*;

public class LoginLoad extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
                DBConnection testDb = new DBConnection();
                Connection con = testDb.DBConnection();   
                mainHtmlPrint htmlPrint = new mainHtmlPrint();
                String htmlPrintOne = htmlPrint.htmlReturn();
                String htmlPrintTwo = htmlPrint.secondHtmlReturn();
                String query1 = "select USERNAME, USER_PASSWORD from USERS";
                 
         try
            {
                //What kind of response is going to the browser
                res.setContentType("text/html"); 
		PrintWriter pw=res.getWriter();
		//String name=req.getParameter("name");
                //pw.println("Welcome Hi "+name);
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery(query1);

                pw.print(htmlPrintOne);  
                pw.print(htmlPrintTwo); 
                pw.print("<body>\n"
                        +"<table align='center' width='50%'>\n" 
                        +"<tr>\n" 
                        +"<td colspan=\"2\">\n" 
                        +"<h1 align =\"center\">Sign Up</h1>\n" 
                        +"</td>\n" 
                        +"<tr>\n" 
                        +"<td>\n"
                        
                        //form for sign up
                        //action and method commented out due to failure to properly function with post method
                        +/*"<form method = 'post' "action=\"/servlet/submitted.html\"*/"<form name=\"signup\" align=\"center\">\n"
                        +"Username<input type=\"text\" name=\"newUserId\"/><br/>\n"
                        +"Password<input type=\"password\"name=\"newPassword\"/><br/>\n"
                        +"First Name<input type=\"text\"  name=\"firstName\"/><br />\n"
                        +"Last Name<input type=\"text\" name=\"lastName\"/><br/>\n"
                        +"Address<input type=\"text\" name=\"address\"/><br/>\n"
                        +"City<input type=\"text\" name=\"city\"/><br/>\n"
                        +"State<input type=\"text\" name=\"state\"/><br/>\n"
                        +"Zipcode<input type=\"text\" name=\"zipCode\"/><br/>\n"
                        +"<input type=\"submit\"  name=\"signUpButton\" value=\"Sign-Up\" onClick=\"signUp(this.form)\">"
                        
                        +"<script>document.getElementById(\"signUpButton\").addEventListener(\"click\",signUp);</script>"
                        +"<input type=\"reset\" value=\"Clear\"/>\n"
                        +"<br/>\n" 
                        +"</form>\n" 
                        
                        +"</td>\n" 
                        +"</tr>\n" 
                        +"</table>\n");

                //prints log in header and text boxes
                pw.print("<h1 align=\"center\">Log-In</h1>\n"
                        +"<div align=\"center\">"
                        + "<form name=\"login\" align=\"center\">\n"
                        +"Username<input type=\"text\" name=\"userid\"/><br>\n"
			+"Password<input type=\"password\" name=\"pswrd\"/><br>\n"
                        +"<button type=\"button\" onClick=\"check(this.form)\" id=\"login\">" + "Login</button>"
                        +"<script>document.getElementById(\"login\").addEventListener(\"click\",check);</script>"
			+"<input type=\"reset\" value=\"Clear\"/>\n"
			+"</form></div>");

                
                //verifies login
                pw.print(
                        "<script language=\"javascript\">\n"
                        +"function check(form)\n"
                        +"{\n"
                        +"if(form.userid.value ==\"VGCDerrick\" && form.pswrd.value ===\"rick\")\n"
			+"{\n"
			+"window.open('LoggedIn.html');\n"
			+"}\n"
			+"else{alert(\"Error Password or Username\");\n}"
                        +"}\n"
                        +"</script>");
                
                //verifies sign up is valid
                pw.print("<script>"
                        +"function signUp(form)\n"
                        +"{"
                        +"if(form.newUserId.value == \"VGCDerrick\" && form.newPassword.value ==\"rick\" && form.firstName.value ==\"Derrick\")\n"
                            +"{"
                            +"window.open('submitted.html');\n"
                            +"}"
                        +"else{alert(\"Must enter valid information\");\n}"
                        +"}"
                        + "</script>");
                
                pw.print("<hr>\n"
                        +"<p style=\"font-size: 12px; text-align: center\">Copyright Das Schwarze Hahnchen (R) 2017</p>"
                );
                
                pw.print("</body>\n");

                con.close();
            }
            catch(Exception e)
            {
		PrintWriter pw=res.getWriter();
                //pw.println("ERROR "+ e.getMessage());
            }	
        }
        
        public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
            DBConnection testDb = new DBConnection();
            Connection con = testDb.DBConnection();   
            String query1 = "Select USERNAME from USERS;";
            
            try
            {
                res.setContentType("text/html"); 
                PrintWriter pw=res.getWriter();     
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery(query1);
                String userName = rs.getString("USERNAME");
                
                if(!req.getParameter("newUserName").equals(userName))
                {
                   stmt.executeUpdate("INSERT INTO USERS (USERNAME, USER_PASSWORD, FIRST_NAME, LAST_NAME, ADDRESS, CITY, STATE_ABBR, ZIPCODE, USERTYPE) VALUES('" + req.getParameter("newUserName")+"','"+req.getParameter("newPassword")+"','"+req.getParameter("firstName")+"','"+req.getParameter("lastName")+"','"+req.getParameter("address")+"','"+req.getParameter("city")+"','"+req.getParameter("state")+"','"+req.getParameter("zipCode")+",'CUSTOMER');");
                   JOptionPane.showMessageDialog(null, "User added!");
                   /*pw.print("<script>"
                            + "function alertWinning(){alert(\"It worked\");} "
                            + "alertWinning();"
                            + "</script>");*/
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Nope");
                    /*pw.print("<script>"
                            + "function alertFunction(){alert(\"Error Password or Username\");} "
                            + "alertFunction();"
                            + "</script>");*/
                }
                
            
            }
            catch(SQLException e)
            {
                
            }
        }
}